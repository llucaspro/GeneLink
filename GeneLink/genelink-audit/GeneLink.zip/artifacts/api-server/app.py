import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, render_template, jsonify, request
import requests as http_requests
from flask_socketio import SocketIO, emit
from flask_cors import CORS

from db.init_db import init_db
from db.connection import get_connection
from routes.auth import auth_bp, token_required
from routes.genes import genes_bp
from routes.forum import forum_bp

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("SESSION_SECRET", "genelink-dev-secret-2024")

CORS(app, resources={r"/api/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet", logger=False, engineio_logger=False)

app.register_blueprint(auth_bp, url_prefix="/api")
app.register_blueprint(genes_bp, url_prefix="/api")
app.register_blueprint(forum_bp, url_prefix="/api")


# ── Frontend page routes ────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/login")
def login_page():
    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/search")
def search():
    return render_template("search.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.route("/forum")
def forum():
    return render_template("forum.html")


@app.route("/forum/<int:post_id>")
def forum_post(post_id):
    return render_template("forum_post.html")


@app.route("/chat")
def chat():
    return render_template("chat.html")


# ── Chat WebSocket ──────────────────────────────────────────────────────────

def _get_recent_messages(limit=50):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            """SELECT cm.id, cm.message, cm.created_at, cm.username
               FROM chat_messages cm
               ORDER BY cm.created_at DESC LIMIT %s""",
            (limit,),
        )
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return list(reversed([dict(r) for r in rows]))
    except Exception:
        return []


@socketio.on("connect")
def handle_connect():
    messages = _get_recent_messages()
    emit("history", {"messages": messages})


@socketio.on("send_message")
def handle_message(data):
    token = data.get("token", "")
    message = (data.get("message") or "").strip()
    if not message or len(message) > 2000:
        return

    import jwt as pyjwt
    SECRET_KEY = os.environ.get("SESSION_SECRET", "genelink-dev-secret-2024")
    try:
        payload = pyjwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        user_id = payload["user_id"]
    except Exception:
        emit("error", {"message": "Authentication required to send messages"})
        return

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT username, avatar_initials FROM users WHERE id=%s", (user_id,))
        user = cur.fetchone()
        if not user:
            cur.close()
            conn.close()
            return
        cur.execute(
            "INSERT INTO chat_messages (user_id, username, message) VALUES (%s, %s, %s) RETURNING id, created_at",
            (user_id, user["username"], message),
        )
        row = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()
        socketio.emit("new_message", {
            "id": row["id"],
            "username": user["username"],
            "avatar_initials": user["avatar_initials"],
            "message": message,
            "created_at": str(row["created_at"]),
        })
    except Exception as e:
        emit("error", {"message": "Failed to send message"})


@socketio.on("disconnect")
def handle_disconnect():
    pass


# ── Supabase Auth ────────────────────────────────────────────────────────────

@app.route("/api/supabase-config")
def supabase_config():
    url = os.environ.get("SUPABASE_URL", "")
    anon_key = os.environ.get("SUPABASE_ANON_KEY", "")
    if not url or not anon_key:
        return jsonify({"error": "Supabase não configurado"}), 404
    return jsonify({"url": url, "anon_key": anon_key})


@app.route("/api/supabase-auth", methods=["POST"])
def supabase_auth():
    import jwt as pyjwt
    import bcrypt
    data = request.get_json() or {}
    access_token = data.get("access_token", "")
    sb_user = data.get("user", {})

    supabase_url = os.environ.get("SUPABASE_URL", "")
    if not supabase_url or not access_token:
        return jsonify({"error": "Dados de autenticação inválidos"}), 400

    try:
        # Verifica o token com Supabase
        verify_url = f"{supabase_url}/auth/v1/user"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "apikey": os.environ.get("SUPABASE_ANON_KEY", ""),
        }
        resp = http_requests.get(verify_url, headers=headers, timeout=8)
        if resp.status_code != 200:
            return jsonify({"error": "Token Supabase inválido"}), 401
        sb_data = resp.json()
        email = sb_data.get("email", "")
        sb_id = sb_data.get("id", "")
        if not email:
            return jsonify({"error": "E-mail não disponível na conta social"}), 400

        conn = get_connection()
        cur = conn.cursor()

        # Busca usuário existente pelo e-mail
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()

        if not user:
            # Cria novo usuário a partir do login social
            meta = sb_data.get("user_metadata", {})
            full_name = meta.get("full_name") or meta.get("name") or email.split("@")[0]
            username_base = email.split("@")[0].replace(".", "").lower()[:20]
            username = username_base
            suffix = 1
            while True:
                cur.execute("SELECT id FROM users WHERE username=%s", (username,))
                if not cur.fetchone():
                    break
                username = f"{username_base}{suffix}"
                suffix += 1

            avatar_initials = (full_name[:2] if full_name else username[:2]).upper()
            dummy_hash = bcrypt.hashpw(sb_id.encode(), bcrypt.gensalt()).decode()
            cur.execute(
                """INSERT INTO users (username, email, password_hash, full_name, avatar_initials)
                   VALUES (%s, %s, %s, %s, %s)
                   RETURNING id, username, email, full_name, avatar_initials, institution, research_area, bio, created_at""",
                (username, email, dummy_hash, full_name, avatar_initials),
            )
            user = cur.fetchone()
            conn.commit()

        cur.close()
        conn.close()

        user_dict = dict(user)
        SECRET_KEY = os.environ.get("SESSION_SECRET", "genelink-dev-secret-2024")
        token = pyjwt.encode(
            {"user_id": user_dict["id"], "exp": __import__("datetime").datetime.utcnow() + __import__("datetime").timedelta(days=7)},
            SECRET_KEY, algorithm="HS256"
        )
        if isinstance(token, bytes):
            token = token.decode("utf-8")
        user_dict["created_at"] = str(user_dict.get("created_at", ""))
        return jsonify({"token": token, "user": user_dict})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Health check ────────────────────────────────────────────────────────────

@app.route("/api/healthz")
def healthz():
    return jsonify({"status": "ok", "service": "GeneLink API"})


# ── Entrypoint ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 8080))
    print(f"[GeneLink] Starting on port {port}")
    socketio.run(app, host="0.0.0.0", port=port, debug=False)
